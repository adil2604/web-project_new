<?php
$selected=$_POST['selected'];
$link = mysqli_connect("localhost", "adil", "221634adil", "webtasks");
$sql = "SELECT cars.id,makers.title, cars.model,cars.price,cars.image FROM cars INNER JOIN makers ON cars.maker_id=makers.maker_id";
$query=mysqli_query($link,$sql);
while ($car=mysqli_fetch_assoc($query)){
  if($selected==$car['title']){
    echo "<div class='car'><img src='".$car['image']."' style='width:50%;height:100%;'><div class='title'>".$car['title']." ".$car['model']."</div><div class='price'>Price: ".$car['price']."$</div></div>";

  }
}

 ?>
