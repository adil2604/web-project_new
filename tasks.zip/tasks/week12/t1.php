<?php
require_once '../../vendor/autoload.php';

$loader = new Twig_Loader_Filesystem('/');
$twig = new Twig_Environment($loader);
$template = $twig->loadTemplate('t1Result.html');
$companies = ["Toyota","Mercedes","BMW"];
echo $template->render(array('companies'=>$companies));
