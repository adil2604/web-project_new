<?php
$usernames = ["billgates","johndoe","stevejobs"];
$link = mysqli_connect("localhost", "adil", "221634adil", "webtasks");
?>
<html>
<head>
	<title>task9_1</title>
	<style media="screen">
		body,html{
			width: 100%;
			height: 100%;
			margin:0;

		}
		.cars{
			width: 100%;
			height: 30vw;
			display: flex;
			flex-direction: row;
			flex-wrap: wrap;


		}
		.car{
			margin:1vw;
			width: 20%;
			height: 30%;
			border:1px solid red;
			display: flex;
			flex-direction: row;
		}
		.car .title{
			font-size: 1.3vw;
			font-weight: bold;
		}
		.car .price{
			color:green;

		}
	</style>
</head>
<body>

	<select id='maker' class="" name="makers">
		<?php
		$sql = "SELECT DISTINCT title FROM `makers`";
		$makers=[];
		echo "<option>Select</option>";
		$query=mysqli_query($link,$sql);
		while($car=mysqli_fetch_assoc($query)){
			echo "<option>".$car['title']."</option>";
		}
		?>
	</select>

	<div id='cars' class="cars">

		<!-- <?php
			// echo "<div class='car'><img src='".$car['image']."' style='width:50%;height:100%;'><div class='title'>".$car['maker']." ".$car['model']."</div><div class='price'>Price: ".$car['price']."$</div></div>";
			//
		?> -->

	</div>

<script type="text/javascript" src="script.js">

</script>
</body>
</html>
