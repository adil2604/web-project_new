
<button onclick="convert({},'menu.navbar-e.info','')">convert</button>


<script type="application/javascript" src="script.js"></script>