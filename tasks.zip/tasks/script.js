function items_to_tree(items,obj=null) {
    var arr = {};
    var parts = items.split(".");
    var last = parts.pop();
    var cursor = arr;
    parts.forEach(function(part){
        if(!cursor[part]) cursor[part] = {};
        cursor = cursor[part];

    });
    cursor[last] = {};
    if (obj!==null){
        for (let prop1 in obj) {
            for(let prob in arr){
                console.log(prob)
                if (obj.hasAttribute(prob)) {

                    obj[prop1] = arr[prob];
                }
            }

        }
        return obj;
    }

    return arr;
}
function mergeDeep(...objects) {
    const isObject = obj => obj && typeof obj === 'object';

    return objects.reduce((prev, obj) => {
        Object.keys(obj).forEach(key => {
            const pVal = prev[key];
            const oVal = obj[key];

            if (Array.isArray(pVal) && Array.isArray(oVal)) {
                prev[key] = pVal.concat(...oVal);
            }
            else if (isObject(pVal) && isObject(oVal)) {
                prev[key] = mergeDeep(pVal, oVal);
            }
            else {
                prev[key] = oVal;
            }
        });

        return prev;
    }, {});
}




function addJson(data) {
    fetch('your_json_file.json').then(function (response) {
        response.text().then(function (text) {
            var objs = JSON.parse(text);
            let ans=mergeDeep(data,objs);
            console.log(ans)
            helper(ans)

        });
    })
}
function helper(ans) {
    let request = new XMLHttpRequest();
    // посылаем запрос на адрес "/user"
    request.open("POST", "/user", true);
    request.setRequestHeader("Content-Type", "application/json");
    request.addEventListener("load", function () {
        // получаем и парсим ответ сервера
        let receivedUser = JSON.parse(request.response);
        console.log(receivedUser);   // смотрим ответ сервера
    });
    request.send(JSON.stringify(ans));
}
var qq=items_to_tree('menu.fu.du.qu')
console.log(qq);

var ss=items_to_tree('menu.fu.bu.su')
let data=mergeDeep(qq,ss);
console.log(data)
addJson(data);



