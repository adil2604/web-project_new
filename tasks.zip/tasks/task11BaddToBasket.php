<?php

$id = $_GET["id"];
$basket = [];
if (isset($_COOKIE["basket"])){
	$basket = json_decode($_COOKIE["basket"]);
}
if (!in_array($id,$basket)){
    array_push($basket,$id);
    setcookie("basket",json_encode($basket));
}
else
    echo "Already in the basket ";
?>
<a href="task11B.php">Back</a>
